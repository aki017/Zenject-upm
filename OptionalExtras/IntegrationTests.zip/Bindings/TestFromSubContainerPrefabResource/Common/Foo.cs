﻿using UnityEngine;

namespace Zenject.Tests.Bindings.FromSubContainerPrefabResource
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
