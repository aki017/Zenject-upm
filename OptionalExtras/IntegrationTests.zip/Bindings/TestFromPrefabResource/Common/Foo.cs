﻿using UnityEngine;

namespace Zenject.Tests.Bindings.FromPrefabResource
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
